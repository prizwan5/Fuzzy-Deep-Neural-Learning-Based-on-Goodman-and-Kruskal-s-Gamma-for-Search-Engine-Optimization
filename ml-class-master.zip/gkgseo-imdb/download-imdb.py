# curl http://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz
# tar xvfz aclImdb_v1.tar.gz
