self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "0b6140c3d653dac46660",
    "url": "/static/js/main.2b489c34.chunk.js"
  },
  {
    "revision": "e9d3e5782a63b916f779",
    "url": "/static/js/2.bb65d6fc.chunk.js"
  },
  {
    "revision": "0b6140c3d653dac46660",
    "url": "/static/css/main.679383b4.chunk.css"
  },
  {
    "revision": "4352c2bee5b1edf84e2cfbfc04016926",
    "url": "/index.html"
  }
];