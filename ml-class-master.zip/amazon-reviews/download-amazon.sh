wget http://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Video_Games_5.json.gz 
gunzip xvfz reviews_Video_Games_5.json.gz
